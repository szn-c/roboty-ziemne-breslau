> **AKTUALIZACJA (najnowsze liczby i obrysy): zobacz `00_WYNIKI/CZYTAJ_NAJPIERW.md`.**
> Ta instrukcja opisuje wariant z Civil 3D i powstała przed zebraniem danych geometrii. Obrysy ścianki i hal z Kroków 4.7, 4.8 i 11 oraz liczby „wstępne"
> są **nieaktualne**: szkic obrysów był o 3,7% za mały. Poprawne obrysy to pliki `04_gstarcad_siatka/wierzcholki_*.txt` i `.dxf`,
> a poprawny bilans to `00_WYNIKI/BILANS_ROBOT_ZIEMNYCH_dz190.xlsx`. Jeśli liczysz w Civil 3D, użyj tych obrysów i rzędnej dna 121,97 m npm.

# Roboty ziemne dz. 1/90 w Civil 3D – instrukcja krok po kroku dla początkujących

## 0. Na czym polega cała metoda

Civil 3D liczy objętości tak, że porównuje dwie **powierzchnie**. Powierzchnia to cyfrowy model terenu: siatka trójkątów rozpięta na punktach z wysokościami. Możesz ją sobie wyobrazić jak prześcieradło naciągnięte na punktach.

- Masz dwie powierzchnie, na przykład „teren dziś” i „dno wykopu”. Program liczy, ile ziemi jest między nimi.
- Na humus nie robimy dodatkowej powierzchni „spód humusu”. Zamiast tego robimy powierzchnię, której „wysokość” jest **grubością humusu** (np. 0,6 m). Porównujemy ją z płaską powierzchnią na wysokości 0. Wynik to objętość humusu. Ten sam trik stosujemy dla nasypu i dla piasków.
- Program liczy „w kółko” tylko w granicach, które mu wskażesz zamkniętą linią (polilinią): obszar zdejmowania humusu, obrys wykopu itd.

**Zasada nr 1:** w polskiej geodezji X oznacza północ, a Y wschód. W Civil 3D północ to **Northing (N)**, a wschód to **Easting (E)**. Pliki z tej paczki mają już dobrą kolejność (P, N, E, Z, D), więc nic nie zamieniaj.

**Zasada nr 2:** polecenia w Civil 3D są po angielsku (polskiej wersji nie ma). W instrukcji podaję angielską nazwę, a w nawiasie, co ona oznacza.

---

## 1. Co przygotować przed startem

| Co | Skąd | Po co |
|---|---|---|
| Civil 3D (dowolna wersja od ok. 2020) | – | – |
| Teren: mapa do celów projektowych (DWG) od projektanta **albo** NMT z Geoportalu (darmowy); plik punktów od geodety nie jest konieczny | projektant / geoportal.gov.pl | powierzchnia terenu |
| Projekt: obrys garażu podziemnego / płyty, rzędna dna wykopu, sposób zabezpieczenia wykopu (skarpy czy obudowa), zakres zdejmowania humusu, pole terenów zielonych | projektant / PZT | powierzchnia wykopu i obrysy |
| Ta paczka plików | – | wszystko z otworów |

> Najlepiej poprosić geodetę o **plik punktów wysokościowych w formacie TXT/CSV (nr, X, Y, H)** z pomiaru po wycince drzew. To najprostsze i najdokładniejsze rozwiązanie.

---

## 2. Co jest w paczce

```
civil3d_roboty_ziemne_dz190/
├── INSTRUKCJA.md                       ← ten plik
├── 01_pliki_punktow_PNEZD/             ← pliki do wczytania do Civil 3D
│   ├── 01_otwory_teren_kontrola.csv    rzędne terenu w otworach (tylko do podglądu/kontroli!)
│   ├── 02_miazszosc_humus.csv          Z = grubość humusu [m]
│   ├── 03_miazszosc_nasyp.csv          Z = grubość nasypu [m] (0 tam, gdzie go nie ma)
│   ├── 04_miazszosc_humus_plus_nasyp.csv  Z = humus + nasyp (wszystko, co zdejmujemy z wierzchu)
│   ├── 05_piaski_nad_dnem_wykopu/      Z = grubość piasków/pospółek między humusem a dnem wykopu
│   │   ├── 05_piasek_nad_dnem_119_00.csv   (dla dna na rzędnej 119,00)
│   │   ├── ... 119_50, 120_00, 120_50, 121_00, 121_50 ...
│   │   └── 05_piasek_nad_dnem_122_00.csv   (dla dna na rzędnej 122,00)
│   ├── 06_zwierciadlo_wody_rzedna_orientacyjnie.csv  rzędna wody gruntowej (opcjonalnie)
│   ├── 07_powierzchnia_ZERO.csv        4 narożniki płaskiej powierzchni Z = 0
│   └── 08_teren_projektowany_plaski_125_89.csv  płaski teren projektowany 125,89 m npm (zastępczy, do podmiany na plan wysokościowy)
├── 02_zestawienia_excel/
│   ├── bilans_robot_ziemnych.xlsx      ← tu wpisujesz wyniki z Civil 3D, liczy odkład/wywóz i tony
│   ├── zestawienie_otworow.csv         tabela otworów
│   └── profile_warstw.csv              wszystkie warstwy z 17 kart otworów
├── 03_dxf_kontrolny/
│   └── otwory_thiessen_dz190.dxf       otwory z opisami + strefy wpływu każdego otworu
└── _skrypt/                            skrypty, którymi wygenerowałem pliki (można pominąć)
```

Format plików punktów to **PNEZD (comma delimited)**: numer, Northing, Easting, wartość Z, opis. Separator to przecinek, część dziesiętna po kropce. Numery punktów w różnych plikach się nie powtarzają, więc nie będzie konfliktów.

**Skąd w plikach miąższości punkty „RAMKA”?** Z samych 17 otworów program rozpiąłby powierzchnię tylko między nimi, a skraje działki zostałyby puste. Dlatego dodałem punkty na prostokącie 30 m poza otworami. Każdy z nich ma wartość z najbliższego otworu. Dzięki temu powierzchnia pokrywa całą działkę.

---

## Krok 1. Nowy rysunek i ustawienia

1. Uruchom Civil 3D.
2. Kliknij **New** (nowy rysunek). Wybierz szablon **`_Autodesk Civil 3D (Metric) NCS.dwt`**. Słowo „Metric” jest ważne, bo oznacza metry.
3. Po lewej powinno być okno **Toolspace** (przybornik). Jeśli go nie ma, wpisz w wierszu poleceń na dole `TOOLSPACE` i naciśnij Enter.
   - Zakładka **Prospector** (eksplorator) to drzewko wszystkiego, co jest w rysunku. Będziesz z niej korzystać najczęściej.
4. Tylko jeśli będziesz wczytywać NMT z Geoportalu: w Toolspace przejdź do zakładki **Settings**, kliknij prawym przyciskiem nazwę rysunku → **Edit Drawing Settings** → zakładka **Units and Zone**. Wybierz Categories: **Poland** i układ **2000 strefa 6** (kod EPSG 2177). Zatwierdź **OK**.
5. Zapisz plik (Ctrl+S) np. jako `dz190_roboty_ziemne.dwg`. Zapisuj często.

---

## Krok 2. Wczytanie otworów (do podglądu)

**2a. Punkty otworów**
1. Na wstążce (górne menu) kliknij zakładkę **Insert** → **Points from File** (punkty z pliku).
2. W oknie:
   - **Specify point file format**: wybierz **PNEZD (comma delimited)**,
   - kliknij zielony **+** i wskaż `01_otwory_teren_kontrola.csv`,
   - zaznacz **Add Points to Point Group** i wpisz nazwę grupy `OTWORY`,
   - kliknij **OK**.
3. Nic nie widać? Wpisz `Z` Enter, potem `E` Enter (polecenie Zoom Extents, czyli „pokaż wszystko”). Powinno pojawić się 17 punktów.

**2b. Rysunek kontrolny DXF**
1. Wpisz `INSERT` (lub `XATTACH`) i wskaż `03_dxf_kontrolny/otwory_thiessen_dz190.dxf`. Punkt wstawienia `0,0,0`, skala 1, obrót 0.
2. Zobaczysz kółka otworów z opisem (nr, H, grubość humusu), zielone wieloboki „stref wpływu” każdego otworu (wieloboki Thiessena) i niebieski prostokąt, czyli zasięg powierzchni miąższości.

**Kontrola:** otwory powinny wypaść na swoich miejscach na mapie zasadniczej (wstaw mapę do tego samego rysunku). Jeśli są przesunięte o tysiące kilometrów albo obrócone, coś jest nie tak z układem lub zamianą X/Y.

> ⚠ Współrzędna Y otworu 12 (6433688,2) była nieczytelna w pliku DGI i została odtworzona z mapy. Sprawdź ją w papierowej DGI. Jeśli jest inna, popraw ją w plikach CSV (Notatnik) we wszystkich plikach, w wierszu z opisem `...OTW12`.

---

## Krok 3. Powierzchnia istniejącego terenu (EG)

Powierzchnię nazwij **`EG`** (ang. *existing ground*, czyli teren istniejący).

### 3.0 Czy plik od geodety jest konieczny?

**Nie.** Warto jednak wiedzieć, na co teren wpływa, a na co nie:

| Wynik | Czy zależy od EG? |
|---|---|
| V1 humus, V2 nasyp, V7 piaski | **NIE.** Liczone są z grubości (powierzchnie TH_ vs ZERO), więc teren nie ma znaczenia. |
| V3 wykop (a przez to gliny do wywozu) | **TAK.** Błąd terenu o 0,10 m na 1000 m² wykopu daje ok. 100 m³, czyli ok. 3–4% przy wykopie głębokim na ok. 2,75 m (patrz „Dane z projektu” poniżej). |

Do planowania i kosztorysu wystarczy NMT z Geoportalu albo mapa do celów projektowych. Do rozliczenia z wykonawcą i tak potrzebny będzie pomiar geodezyjny przed robotami i po nich.

**Źródła terenu (od najlepszego):**
1. **Mapa do celów projektowych (DWG)**. Musi istnieć, bo jest wymagana do projektu budowlanego. Poproś o nią projektanta lub inwestora. Mapa w DGI (zał. 4.1) to aktualna mapa zasadnicza z 2025 r. z pikietami wysokościowymi. → **wariant B**
2. **NMT z Geoportalu (plik .asc lub .tif)**. Jest darmowy i dostępny od ręki, ale ma ograniczenia (patrz 3.C). → **wariant C**
3. Plik punktów od geodety (TXT/CSV). → **wariant A**

Najlepiej wczytać NMT, a następnie sprawdzić go pikietami z mapy (punkt 3.D).

**Najpierw utwórz pustą powierzchnię (dotyczy każdego wariantu):**
1. Zakładka **Home** → **Surfaces** → **Create Surface**.
2. Type: **TIN surface**, Name: `EG` → **OK**.
3. W Prospectorze pojawi się **Surfaces → EG → Definition** (definicja, czyli „z czego powierzchnia jest zbudowana”).

### 3.A Plik punktów od geodety (jeśli go dostaniesz)
**Definition** → prawym na **Point Files** → **Add** → format **PNEZ (space delimited)** albo **PNEZ (comma delimited)**, zależnie od separatora w pliku → **OK**.

### 3.B Mapa DWG z pikietami wysokościowymi
1. Otwórz DWG mapy albo skopiuj jej zawartość do swojego rysunku (Ctrl+Shift+C, punkt bazowy `0,0` → Ctrl+V, `0,0`).
2. Sprawdź, czym są pikiety: kliknij jedną i naciśnij Ctrl+1.
   - **Blok lub punkt z wpisaną wysokością (Position Z = 124,7)**: Definition → **Drawing Objects** → **Add** → typ **Blocks** (albo **Points**) → zaznacz pikiety → **OK**.
   - **Tylko napis „124.7” leżący na Z = 0**: wpisz `MOVETEXTTOELEVATION`, zaznacz napisy z wysokościami i naciśnij Enter. Civil podniesie każdy napis na wysokość równą jego treści. Potem Definition → **Drawing Objects** → **Add** → typ **Text** → zaznacz te napisy.
3. **Uwaga:** zaznaczaj wyłącznie wysokości terenu. Numery działek, numery budynków, rzędne studzienek i włazów (np. „wł. 125.40”) czy rzędne dna kanałów zepsują powierzchnię. Najwygodniej najpierw wyłączyć wszystkie warstwy oprócz warstwy pikiet (polecenie `LAYISO` → kliknij pikietę).
4. Pikiety leżą co 15–25 m. Na płaskim terenie to wystarczy.

### 3.C NMT z Geoportalu: pobieranie i wczytanie

**Pobranie:**
1. Wejdź na **www.geoportal.gov.pl**, otwórz mapę i znajdź działkę (wyszukiwarka: „Wrocław, Wojszyce 1/90” albo ul. Lutosławskiego).
2. Włącz sekcję **„Dane do pobrania”** i grupę warstw **„Numeryczny Model Terenu”**.
3. Wybierz warstwę z **PL-KRON86-NH** w nazwie. W tym samym układzie wysokości są DGI i otwory, więc uniknięsz przesunięcia. Jeśli dostępna jest tylko wersja **PL-EVRF2007-NH**, możesz ją wziąć, ale koniecznie zrób korektę z punktu 3.D.
4. Kliknij na mapie w miejscu działki. Pojawi się lista arkuszy z datą pozyskania. Wybierz **najnowszy**, w siatce **1 m** (albo 0,5 m, jeśli jest), w formacie **ASC (ARC/INFO ASCII GRID)** lub GeoTIFF. Pobierz plik i rozpakuj, jeśli przyjdzie jako ZIP.
5. Zanotuj datę pozyskania danych. Jeśli jest sprzed wycinki, teren może się różnić od obecnego o kilka do kilkunastu cm (karpy, koleiny).
6. Sprawdź, w jakim układzie są współrzędne pliku. Zwykle jest to **PL-1992 (EPSG:2180)**, a nie 2000. Układ jest podany w opisie arkusza albo w nazwie pliku.

**Ustawienie układu w rysunku (jednorazowo, potrzebne do przeliczenia z 1992 na 2000):**
1. Toolspace → zakładka **Settings** → prawym na nazwie rysunku → **Edit Drawing Settings** → zakładka **Units and Zone**.
2. Categories: **Poland**. Available coordinate systems: układ **2000 strefa 6** (szukaj „CS2000/18”, „Zone 6” lub kodu **2177**). Jeśli lista jest długa, wpisz `2177` w polu wyszukiwania.
3. Drawing units: **Meters** → **OK**.

**Wczytanie do EG:**
1. Prospector → **Surfaces → EG → Definition** → prawym na **DEM Files** → **Add**.
2. Wskaż pobrany plik (.asc lub .tif).
3. Otworzy się okno **DEM File Properties**:
   - **Coordinate system**: kliknij przycisk z kropkami i wybierz układ **pliku**, czyli 1992 (**EPSG 2180**, „Poland CS92”). Civil sam przeliczy dane do 2000/6. Jeśli plik jest już w 2000/6, wybierz 2177.
   - **Null elevation value**: `-9999` (komórki bez danych zostaną pominięte),
   - kliknij **OK**.
4. Plik obejmuje cały arkusz (kilka km²), więc powierzchnia będzie ciężka. Przytnij ją do okolicy działki: narysuj zamkniętą polilinię ok. 50 m poza granicą działki → Definition → prawym na **Boundaries** → **Add** → Type: **Outer** → **Non-destructive breakline: zaznacz** → wskaż polilinię → **OK**.

### 3.D Kontrola i korekta EG (zrób zawsze)

1. **Statystyka:** zaznacz powierzchnię → **Surface Properties** → **Statistics** → **General**. W obrysie działki wysokości powinny wynosić ok. **124,2–125,2 m**. Jeśli wychodzi np. 300 m, plik ma zły układ albo jednostki.
2. **Porównanie z otworami** (rzędne z DGI):
   - Najedź kursorem na punkt otworu (wczytany w Kroku 2) i chwilę poczekaj. W żółtej podpowiedzi Civil pokaże wysokość powierzchni EG w tym miejscu (**Surface: EG, Elevation**). Jeśli podpowiedź się nie pojawia: zakładka **Analyze** → **Inquiry Tool** → typ zapytania **Surface – Point** → wskaż EG i klikaj kolejne otwory. Wysokość odczytasz w oknie narzędzia.
   - Zapisz różnicę **EG − H otworu** dla kilku otworów (np. 2, 7, 11, 15, 18, 21, 24). Pomocna jest tabela poniżej.
3. **Ocena wyniku:**
   - Różnice rozrzucone w obie strony do ±0,15 m: wszystko w porządku. Rzędne otworów są zaokrąglone do 0,1 m.
   - **Wszystkie różnice z jednym znakiem**, np. EG średnio 0,15–0,25 m wyżej: to przesunięcie układu wysokości (EVRF2007 zamiast KRON86) albo inny czynnik systematyczny. Popraw je: zaznacz EG → **Edit Surface** → **Raise/Lower Surface** → wpisz średnią różnicę **ze znakiem minus** (np. `-0.18`).
   - Pojedynczy otwór różni się o więcej niż 0,3 m: w tym miejscu może być wykop, hałda albo błąd w danych. Sprawdź na ortofotomapie i mapie.
4. Te same porównania warto zrobić z kilkoma pikietami z mapy w DGI, bo są nowsze niż NMT.

| Otwór | H z DGI [m] | EG w tym miejscu [m] | Różnica EG − H |
|---|---|---|---|
| 2 | 124,70 | | |
| 7 | 125,10 | | |
| 11 | 124,40 | | |
| 15 | 124,30 | | |
| 18 | 124,90 | | |
| 21 | 124,80 | | |
| 24 | 124,40 | | |
| **średnia** | | | |

> Jeśli masz zarówno NMT, jak i mapę z pikietami: zbuduj EG z NMT, zrób powierzchnię `EG_MAPA` z pikiet (wariant B) i policz Volumes Dashboard: Base = EG_MAPA, Comparison = EG, w obrysie działki. Cut i Fill pokażą, o ile m³ obie wersje się różnią. Jeśli różnica w wykopie jest mniejsza niż 2–3%, do planowania nie ma znaczenia, którą wersję wybierzesz.

---

## Krok 4. Narysuj obrysy (zamknięte polilinie)

### 4.0 Po co są obrysy

Powierzchnie z Kroku 3 i 5 zajmują duży prostokąt, większy niż działka. Program musi wiedzieć, **w jakim miejscu ma liczyć**. Takie miejsce wskazujesz **obrysem**: linią narysowaną dookoła obszaru, jak ołówkiem na mapie. Linia musi być **zamknięta**, czyli koniec musi się łączyć z początkiem. Inaczej program nie rozpozna, gdzie jest „środek”.

W AutoCAD/Civil 3D taka linia to **polilinia** (polecenie `PLINE`): jeden obiekt złożony z wielu odcinków.

Potrzebujesz trzech (czterech) obrysów:

| Obrys | Co oznacza w terenie | Skąd go wziąć | Do czego służy |
|---|---|---|---|
| `ZAKRES_HUMUS` | cały obszar, z którego koparka zdejmie humus | granica robót z projektu zagospodarowania (PZT). Brak PZT → granica działki 1/90 (czerwona przerywana linia na mapie DGI) | objętość humusu i nasypu (V1, V2) |
| `DNO_WYKOPU` | obrys płaskiego dna wykopu pod garażem | obrys zewnętrznych ścian garażu / płyty fundamentowej z projektu + przestrzeń robocza | objętość wykopu (V3) i piasków (V7) |
| `GORA_WYKOPU` | linia na powierzchni terenu, gdzie zaczyna się wykop (górna krawędź skarpy) | ściany pionowe (obudowa) → taka sama jak dno; skarpy → większa od dna (patrz 4.4) | humus i nasyp leżące w wykopie (V4, V5) |
| `ZIELEN` (opcjonalnie) | tereny zielone do obsiania/obsadzenia | PZT | ile humusu zostawić na odkład |

Schemat (przekrój przez wykop ze skarpami):

```
   GORA_WYKOPU                               GORA_WYKOPU
        |                                         |
  ~~~~~~+  teren  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~+~~~~~~
         \  skarpa                        skarpa /
          \                                     /
           +-----------------------------------+
           |            DNO_WYKOPU             |
                  <- garaż + przestrzeń robocza ->
```

Na rysunku z góry (w planie) widzisz trzy „ramki” jedna w drugiej: najmniejsza to dno, większa to góra wykopu, największa to zakres humusu.

---

### 4.1 Utwórz warstwy (żeby obrysy się nie myliły)

1. Wpisz `LAYER` i Enter. Otworzy się okno warstw.
2. Kliknij ikonę **New Layer** (kartka z gwiazdką) i wpisz nazwę `ZAKRES_HUMUS`.
3. Tak samo utwórz `DNO_WYKOPU`, `GORA_WYKOPU` i `ZIELEN`. Dla wygody nadaj każdej inny kolor (kliknij kwadracik w kolumnie Color).
4. Przed rysowaniem danego obrysu ustaw jego warstwę jako bieżącą: dwuklik na nazwie (pojawi się zielony ptaszek).

---

### 4.2 Wstaw podkład, po którym będziesz rysować

Obrysów nie wymyślasz, tylko **obrysowujesz** rysunki projektanta:
1. Poproś projektanta o **PZT i rzut garażu w DWG, w układzie 2000/6**, czyli „we współrzędnych”.
2. Wstaw je do swojego rysunku: `XATTACH` → plik → Insertion point `0,0,0`, Scale 1, Rotation 0 → OK → `Z` Enter `E` Enter.
3. Sprawdź, czy projekt leży na mapie (granice działki się pokrywają). Jeśli projekt jest „w lokalnych współrzędnych” (leży koło 0,0), poproś projektanta o wersję w układzie albo dopasuj ją poleceniem `ALIGN` do dwóch punktów granicy działki.

---

### 4.3 Jak narysować zamkniętą polilinię

1. Ustaw bieżącą warstwę (np. `DNO_WYKOPU`).
2. Włącz przyciąganie do narożników: naciśnij **F3** (na dole powinno być „Object Snap: ON”). Wpisz `OSNAP` i zaznacz **Endpoint** oraz **Intersection**.
3. Wpisz `PLINE` i Enter.
4. Klikaj kolejno narożniki obrysu (np. narożniki garażu). Kursor sam „przyklei się” do narożnika, gdy pojawi się mały kwadracik.
5. Gdy klikniesz ostatni narożnik, **nie klikaj ponownie w pierwszy**. Wpisz `C` i Enter. To polecenie Close, czyli „zamknij”.
6. Sprawdź: kliknij linię → **Ctrl+1** → w oknie Properties musi być **Closed: Yes**. Pozycja **Area** to pole w m².

> Jeśli przez pomyłkę narysujesz linię niezamkniętą: zaznacz ją → Ctrl+1 → zmień **Closed** na **Yes**.
> Linia z łukami: w trakcie `PLINE` wpisz `A` (Arc), żeby rysować łuk, i `L` (Line), żeby wrócić do odcinków.
> Gotowa polilinia z obrysu? Zamiast klikać narożniki, użyj polecenia `BOUNDARY`: kliknij **wewnątrz** zamkniętego obszaru na podkładzie, a program sam utworzy polilinię dookoła.

---

### 4.4 Każdy obrys po kolei

**`ZAKRES_HUMUS`**
- Obrysuj granicę robót z PZT. Brak PZT → obrysuj granicę działki 1/90.
- Jeśli na części terenów zielonych humusu nie zdejmujesz (zieleń bez zmian), wyłącz je z obrysu. Wtedy V1 nie będzie zawyżone.

**`DNO_WYKOPU`**
1. Narysuj obrys **zewnętrznych lic ścian garażu**, czyli zewnętrznej krawędzi płyty fundamentowej.
2. Powiększ go o **przestrzeń roboczą**, czyli miejsce, w którym robotnicy wykonają izolację i szalunek (zwykle 0,6–1,0 m, ustal z wykonawcą):
   - wpisz `OFFSET` → wpisz odległość, np. `0.8` → Enter → kliknij obrys ścian → kliknij **na zewnątrz** obrysu.
   - Powstanie nowa, większa linia. Przenieś ją na warstwę `DNO_WYKOPU` (zaznacz → Ctrl+1 → Layer).
3. Wykop w obudowie (ścianka berlińska, grodzice): dno = linia obudowy z projektu zabezpieczenia wykopu.

**`GORA_WYKOPU`**
- **Ściany pionowe (obudowa):** skopiuj `DNO_WYKOPU` (`COPY` → punkt bazowy dowolny → ten sam punkt, albo Ctrl+C / Ctrl+V z `0,0`) i zmień warstwę kopii na `GORA_WYKOPU`.
- **Skarpy:** góra jest odsunięta od dna o
  `odsunięcie = głębokość wykopu × nachylenie`.
  Przykład (przekrój 2C): średni teren 124,65, dno 121,97 → głębokość 2,68 m. Skarpa 1:1 → odsunięcie 2,68 m. Skarpa 1:1,5 → 4,02 m.
  Najprościej: `OFFSET` → wpisz odsunięcie (np. `2.68`) → kliknij `DNO_WYKOPU` → kliknij na zewnątrz → zmień warstwę na `GORA_WYKOPU`.
  (Dokładniejszą górę skarpy da Krok 6B. Program wyliczy ją z rzeczywistego terenu. Dla płaskiej działki obie metody dają prawie to samo.)
- Nachylenie skarp ustala projektant lub geotechnik. W glinach w stanie twardoplastycznym często przyjmuje się 1:1. Pod wodą gruntową (u Ciebie od ok. 1–2 m) może być potrzebne łagodniejsze nachylenie albo obudowa.

**`ZIELEN`** (opcjonalnie)
- Obrysuj tereny zielone z PZT. Wystarczy odczytać sumę pól (Ctrl+1 → Area) i wpisać ją do arkusza bilansu.

---

### 4.5 Nie masz jeszcze projektu?

Możesz policzyć **wariant szacunkowy**:
- `ZAKRES_HUMUS` = granica działki 1/90,
- `DNO_WYKOPU` = przybliżony prostokąt garażu narysowany po wymiarach z koncepcji, np. `RECTANG` → kliknij narożnik → wpisz `@60,40` (prostokąt 60 × 40 m),
- `GORA_WYKOPU` = `OFFSET` dna o głębokość × nachylenie.

Gdy projektant przekaże obrysy, podmienisz linie i przeliczysz (Krok 10: **Rebuild**).

---

### 4.6 Kontrola przed przejściem dalej

- [ ] każdy obrys leży na swojej warstwie,
- [ ] każdy ma **Closed: Yes**,
- [ ] dno leży wewnątrz góry wykopu, a góra wewnątrz zakresu humusu,
- [ ] żaden obrys nie wychodzi poza niebieską ramkę z rysunku kontrolnego DXF (tam kończą się powierzchnie grubości),
- [ ] zanotuj pola (Area) wszystkich obrysów, przydadzą się do kontroli w Kroku 8.

---

### 4.7 Obrysy hal z rzutu w PDF (gdy nie masz DWG)

PDF nie ma współrzędnych, więc Civil nie wie, gdzie na ziemi leżą hale. Trzeba go „przybić” do znanych punktów w dwóch krokach:
1. **mapa z DGI (zał. 4.1)** → do otworów (otwory mają współrzędne),
2. **rzut garaży** → do mapy z DGI, po granicy działki (czerwona przerywana linia).

Dokładność ok. ±2–3 m jest wystarczająca. Takie przesunięcie zmienia teren i grubość humusu w hali o kilka cm, czyli objętości o mniej niż 1%. Ważny jest kształt i pole hal, a nie położenie co do centymetra.

**Krok A. Mapa z DGI do otworów**
1. Wpisz `PDFATTACH` i Enter, wskaż PDF z mapą (zał. 4.1). W oknie ustaw: **Specify on-screen** odznaczone, **X = 6433650**, **Y = 5658980**, **Scale = 25.4**, **Rotation = 0** → OK. (Wpisanie X i Y ustawia podkład w pobliżu otworów, a nie w punkcie 0,0, daleko stąd.)
   **Skąd 25,4?** Civil odczytuje rozmiar kartki PDF w calach (1 cal = 25,4 mm). Dlatego do skali 1:1000 potrzebny jest współczynnik 1000 / 39,37 = **25,4**, a do skali 1:250 współczynnik 250 / 39,37 = **6,35**. Kontrola: po wstawieniu mapy A3 w skali 1:1000 w Properties (Ctrl+1) Szerokość ≈ **420 m**, Wysokość ≈ **297 m**.
2. Wpisz `ZOOM`, potem `O` (Object) i kliknij podkład. Zobaczysz mapę.
3. Wpisz `ALIGN` i Enter, zaznacz podkład, Enter.
   - 1. punkt źródłowy: środek numeru/kółka otworu **24** na mapie (zbliż widok rolką). 1. punkt docelowy: punkt otworu 24 w Twoim rysunku (czerwony krzyżyk).
   - 2. punkt źródłowy: otwór **5** na mapie. 2. punkt docelowy: punkt otworu 5. Enter.
   - Na pytanie „Scale objects based on alignment points?” wpisz `Y` i Enter.
4. **Sprawdź:** przybliż otwory 3, 12, 17, 18 i 20. Symbol na mapie powinien leżeć w promieniu 1–2 m od czerwonego krzyżyka. Jeśli nie, powtórz Align na innych dwóch otworach.

**Mapa z DGI jako bonus:** zawiera pikiety wysokościowe terenu (np. 124.7). Po dopasowaniu możesz zamienić ją na obiekty poleceniem `PDFIMPORT` (zaznacz w oknie opcje wektorów i tekstu) i użyć tych napisów jako niezależnej kontroli terenu `EG` (wariant B z Kroku 3), zwłaszcza przy wschodniej granicy, gdzie NMT różni się od otworów.

**Krok B. Rzut garaży do mapy**
1. `PDFATTACH` → wskaż PDF z rzutem garaży. Ustaw X = 6433650, Y = 5658980, **Scale = 6.35** (rzut jest w skali 1:250: 250 / 39,37; skalę i tak poprawi Align), Rotation 0 → OK.
2. `ALIGN` → zaznacz podkład rzutu → dwa narożniki granicy działki (czerwona przerywana linia z literami) widoczne na **obu** rysunkach, najlepiej daleko od siebie (np. narożnik południowo-wschodni **M** i narożnik północno-zachodni **C**/**D**). Punkty źródłowe klikasz na rzucie, docelowe na granicy na mapie DGI. Na pytanie o skalę wpisz `Y`.
3. **Sprawdź:** reszta granicy powinna się pokrywać z czerwoną linią na mapie w promieniu kilku metrów. Jeśli pokrycie jest słabe, sprawdź, czy wybrałeś te same narożniki.

**Krok C. Sprawdź skalę po polu hali**
1. Narysuj `PLINE` wokół jednej hali, np. nr 6 (grubą fioletową linię obrysu). Zamknij `C`.
2. Ctrl+1 → **Area**. Pole w rzucie strefy pożarowej hali 6 to **1390,55 m²** (to pole wewnątrz ścian). Obrys zewnętrzny powinien dać **ok. 1 450–1 550 m²**.
3. Wynik 4 razy mniejszy lub większy oznacza zły współczynnik skali. Popraw `SCALE` z opcją Reference.

**Krok D. Obrysy wszystkich hal**
1. Warstwa `PLYTA_HALE`. Obrysuj `PLINE` zewnętrzną krawędź każdej z 8 hal (osobne zamknięte polilinie). Przyciąganie do linii PDF działa, gdy `PDFOSNAP` = 1 (domyślnie).
2. **Rampy wjazdowe** obrysuj osobno (warstwa `RAMPY`). Tam wykop jest płytszy (spadek rampy 15% i 5%).
3. `OFFSET` każdej hali o **1,0 m** na zewnątrz (0,1 m chudy beton + ok. 0,9 m przestrzeni roboczej, ustal z wykonawcą). Wynik na warstwę `DNO_WYKOPU`.
4. Ustaw rzędną: zaznacz wszystkie `DNO_WYKOPU` → Ctrl+1 → **Elevation = 121.97**.
5. `GORA_WYKOPU`: patrz Krok 4.4 (osobno dla każdej hali).
6. **Powierzchnia WYKOP dla 8 hal:** Create Surface → TIN `WYKOP` → Definition → **Contours** → Add → zaznacz **wszystkie 8** polilinii `DNO_WYKOPU`. **Boundaries pomiń.** Objętość: Volumes Dashboard, Base = `EG`, Comparison = `WYKOP`, i **Add bounded volume dla każdej hali osobno** (8 razy, każdy obrys `DNO_WYKOPU`). Wyniki (Cut) zsumuj w Excelu.

> Wariant ze skarpami wymaga większych obrysów górnych i osobnej analizy, bo przy sąsiednich halach (odstęp 5–10 m) skarpy z sąsiednich wykopów mogą się przecinać. Zacznij od wariantu z obudową (ściany pionowe), a skarpy policzysz po decyzji projektanta.

---

### 4.8 Rzut z zabezpieczeniem wykopu (ścianka): położenie po siatce 50 m

Ten rzut ma własną **siatkę współrzędnych**: duże krzyże „+” co 50 m, z opisami (np. **5659050** i **6433700**). Dzięki temu nie potrzebujesz mapy DGI, żeby go umieścić, a dokładność jest lepsza niż po granicy działki.

1. `PDFATTACH` → plik rzutu ze ścianką. X = 6433650, Y = 5658980, Scale = 1, Rotation = 0 → OK. Potem `ZOOM` → `O` → kliknij podkład (jest na razie bez właściwej skali).
2. `ALIGN` → zaznacz podkład → Enter.
   - 1. punkt źródłowy: krzyż siatki przy opisie **5659050 / 6433700** (sprawdź opisy na rzucie). 1. punkt docelowy: wpisz z klawiatury `6433700,5659050` i Enter (najpierw wschód, potem północ).
   - 2. punkt źródłowy: inny krzyż, możliwie daleko od pierwszego. Jego współrzędne wyliczasz z siatki: w prawo +50 m wschodu, w dół −50 m północy. Wpisz je tak samo z klawiatury.
   - Na pytanie o skalowanie wpisz `Y`.
3. **Sprawdź:** krzyże siatki mają leżeć na swoich współrzędnych (`ID`). Dodatkowo otwory 21, 23 i 20 powinny leżeć tuż przy zachodniej ściance, otwór 24 przy północnej, a otwory 7 i 18 przy południowej.
4. Obrysuj `PLINE` niebieską przerywaną linię (ściankę), zamknij `C`, warstwa `SCIANKA`. **Kontrola skali:** Ctrl+1 → Length ≈ **565 m** (tyle podaje rzut), Area ≈ **19 600 m²** (±5%). Inne wartości oznaczają zły współczynnik skali.
5. Użycie obrysu `SCIANKA`:
   - `ZAKRES_HUMUS` = ścianka (humus i nasyp zdejmujesz z całego terenu wewnątrz),
   - **wariant B** (kopiemy cały obszar w ściance): `DNO_WYKOPU` = `GORA_WYKOPU` = ścianka,
   - **wariant A** (kopiemy tylko pod halami): obrysy hal z Kroku 4.7 D, ścianka służy tylko do zakresu humusu.

---

## Krok 5. Powierzchnie miąższości (humus, nasyp, piaski) i powierzchnia ZERO

Każdą robisz tak samo:
1. **Home → Surfaces → Create Surface → TIN surface**, wpisz nazwę z tabeli poniżej → **OK**.
2. W Prospectorze: **Surfaces → [nazwa] → Definition** → prawym na **Point Files** → **Add**.
3. Format **PNEZD (comma delimited)** → wskaż plik → **OK**.

| Nazwa powierzchni | Plik |
|---|---|
| `ZERO` | `07_powierzchnia_ZERO.csv` |
| `TH_HUMUS` | `02_miazszosc_humus.csv` |
| `TH_NASYP` | `03_miazszosc_nasyp.csv` |
| `TH_PIASEK_121_97` | `05_piaski_nad_dnem_wykopu/05_piasek_nad_dnem_121_97.csv` (dno 121,97 m = posadzka 122,57 − płyta 0,50 − chudy beton 0,10). Kontrolnie: `121_90` i `122_00`. Inna rzędna dna → poproś o wygenerowanie pliku |
| `TEREN_PROJ` | `08_teren_projektowany_plaski_125_89.csv` – **zastępczy** płaski teren 125,89 m npm (z przekroju 2C). Docelowo zastąp go powierzchnią z planu wysokościowego/PZT (patrz Krok 6C) |
| `ZW` (opcjonalnie) | `06_zwierciadlo_wody_rzedna_orientacyjnie.csv` |

**Ważne:**
- Pliki miąższości dodajesz **do definicji powierzchni** (Point Files), a **nie** wczytujesz ich jako punkty przez Insert. Inaczej narobisz w rysunku setek punktów na wysokości 0,5 m.
- Powierzchnie TH_ zobaczysz na rysunku „przy ziemi” (Z ok. 0–3 m), z dala od terenu na wysokości 124 m. Tak ma być.
- Kontrola: **Surface Properties → Statistics**. Dla TH_HUMUS minimum powinno wynosić 0,40, a maksimum 0,80.

*Opcjonalnie (wygładzenie):* zaznacz TH_HUMUS → **Edit Surface → Smooth Surface** → metoda **Natural Neighbor Interpolation**, siatka np. 2×2 m w obrysie ZAKRES_HUMUS. Daje to łagodniejsze przejścia między otworami. Wynik zmienia się zwykle o kilka procent. Możesz policzyć obie wersje i porównać.

---

### Krok 5.5. Test całego procesu na obrysie otworów (zrób przed obrysami z projektu)

Zanim narysujesz prawdziwe obrysy, sprawdź, czy wszystko działa, na gotowym obrysie testowym (otoczka wypukła 17 otworów, ok. 15 480 m²).

1. Wpisz `SCRIPT` → wskaż `03_dxf_kontrolny/rysuj_obrys_testowy.scr`. Powstanie zamknięta polilinia na warstwie `ZAKRES_TEST` (skrypt przywraca też przyciąganie do punktów, które wcześniej wyłączył skrypt z otworami).
2. Analyze → Volumes Dashboard → Create new volume surface: nazwa `TEST_HUMUS`, Base = `ZERO`, Comparison = `TH_HUMUS`.
3. Kliknij ikonę Add bounded volume, wskaż polilinię `ZAKRES_TEST`.
4. Odczytaj **Fill**. To samo zrób dla nasypu (`TH_NASYP`).

**Oczekiwany wynik** (interpolacja liniowa TIN, taka jak w Civil 3D): humus ok. **9 700 m³** (średnia grubość 0,63 m), nasyp ok. **400 m³**. Różnica do kilku procent jest normalna, bo Civil inaczej dzieli trójkąty. Jeśli wynik jest wielokrotnie inny, patrz Krok 10.

---

## Krok 6. Powierzchnia wykopu `WYKOP`

### Wariant 6A – wykop w obudowie (ściany pionowe). Najprostszy.
1. Kliknij polilinię `DNO_WYKOPU` → Ctrl+1 → w polu **Elevation** wpisz rzędną dna wykopu (np. `121.97`). Rzędna dna = ±0,00 (126,00) − 3,43 (posadzka garażu wg przekroju) − grubość płyty fundamentowej − chudy beton 0,10 − ewentualna podsypka. **Grubość płyty weź od konstruktora** (płyta 0,50 m potwierdzona, wychodzi 121,97; patrz Krok 6D).
2. **Create Surface → TIN**, nazwa `WYKOP`.
3. **Definition → Contours → Add** → zaznacz polilinię `DNO_WYKOPU` → **OK**.
4. **Definition → Boundaries → Add** → Type: **Outer** → zaznacz tę samą polilinię → **OK**.
5. `GORA_WYKOPU` = `DNO_WYKOPU` (skopiuj polilinię).

### Wariant 6B – wykop ze skarpami
1. Zakładka **Home → Feature Line → Create Feature Lines from Objects** (linia charakterystyczna z obiektu). Zaznacz `DNO_WYKOPU` i naciśnij Enter.
   - Site: kliknij ikonę i utwórz nowy, nazwa `WYKOP`,
   - zaznacz **Assign elevations** → **OK** → w następnym oknie wpisz **Elevation** = rzędna dna (np. 121.97).
2. **Home → Grading → Grading Creation Tools** (narzędzia skarpowania). Pojawi się mały pasek narzędzi:
   - pierwsza ikona (**Set the Grading Group**): utwórz grupę `WYKOP_SKARPY`, zaznacz **Automatic Surface Creation**, kliknij **OK**. W kolejnym oknie zostaw nazwę powierzchni lub wpisz `WYKOP`,
   - **Set the Target Surface**: wybierz `EG`,
   - z listy kryteriów wybierz **Grade to Surface** (skarpa do terenu),
   - kliknij ikonę **Create Grading**. Wskaż linię dna i kliknij **na zewnątrz** niej (skarpa idzie na zewnątrz). „Apply to entire length?”: **Yes**. Cut format: **Slope**, Cut slope: np. `1` (czyli 1:1, ustal z projektantem/geotechnikiem). Fill slope może być dowolny, bo tu nasypu nie ma.
   - na pasku wybierz **Create Infill** i kliknij **wewnątrz** obrysu dna. Wypełni to płaskie dno.
3. Górna krawędź skarp: zaznacz powierzchnię `WYKOP` → **Surface Tools → Extract from Surface → Extract Objects** → zaznacz tylko **Border** → **OK**. Powstała polilinia to `GORA_WYKOPU`. Jeśli jest 3D, spłaszcz ją poleceniem `FLATTEN` albo wpisz Elevation 0.

> Wykopy pod drogi, parkingi i sieci zrób tak samo jako osobne powierzchnie z osobnymi obrysami. Najlepiej zacznij od samego garażu.

---

### 6C. Teren projektowany i nasypy (ważne: teren będzie podniesiony)

Przekrój B-B budynku 2C pokazuje **±0,00 = 126,00 m npm** i **teren projektowany 125,89 m npm**. Istniejący teren ma średnio **124,65 m**, więc wokół budynków teren zostanie **podniesiony o około 1,2 m**. W bilansie oznacza to duże zapotrzebowanie na grunt (nasypy), a nie tylko wywóz.

1. Utwórz powierzchnię `TEREN_PROJ`: Create Surface → TIN → Definition → Point Files → Add → `08_teren_projektowany_plaski_125_89.csv` (format PNEZD comma delimited).
   To jest **wartość zastępcza**: płaski teren 125,89 m. Prawdziwy teren (drogi, parkingi, spadki, zieleń) jest w planie wysokościowym lub PZT. Poproś projektanta o DWG z rzędnymi projektowanymi i zbuduj z nich powierzchnię tak samo jak EG (wariant B z Kroku 3).
2. Objętość nasypu: Volumes Dashboard → nowa objętość `VOL_NASYP_PROJ`, Base = `EG`, Comparison = `TEREN_PROJ`, obrys = granica robót **bez obrysu garażu** (pod budynkiem wykop, nie nasyp). Odczytaj **Fill** (tyle gruntu trzeba dowieźć lub wbudować) i **Cut** (nadmiar terenu do obniżenia).
3. Do zapotrzebowania dolicz humus zdjęty spod nasypu (V1 w strefie nasypu). Humus pod nasypem zdejmujemy, więc nasyp musi być grubszy o jego grubość.
4. Wynik wpisz w arkuszu bilansu (pole „Zapotrzebowanie na grunt z wykopu”).

Grunt z wykopu można wbudować w nasyp tylko wtedy, gdy dopuści to geotechnik. Gliny spod zwierciadła wody są mokre. W arkuszu domyślnie zakładam, że **gliny idą na wywóz** (0%). Zmień udział w żółtym polu po uzyskaniu opinii.

### 6D. Dane z przekroju B-B (budynek 2C) i jak z nich wyliczyć dno wykopu

| Z przekroju | Wartość |
|---|---|
| ±0,00 (posadzka parteru) | 126,00 m npm |
| Posadzka garażu | −3,43 → **122,57 m npm** |
| Korytka odwodnieniowe | −3,51 → 122,49 m npm (lokalnie) |
| Teren projektowany | 125,89 m npm (±0,00 − 0,11) |
| Chudy beton pod płytą | 0,10 m |
| Płyta fundamentowa | „biała wanna”, beton W8, grubość wg projektu konstrukcji (**nieznana**) |
| Podszybie windy | min. 110 cm pod posadzką garażu → ok. 121,47 m npm (lokalnie) |

**Dno wykopu** = 122,57 − 0,50 (płyta, potwierdzona) − 0,10 (chudy beton) = **121,97 m npm**. Jeśli projekt przewiduje jeszcze podsypkę, wylewkę lub warstwę ochronną pod chudym betonem, obniż dno o jej grubość. **Każde 10 cm głębokości to około 1 200–1 300 m³ wykopu na wszystkie hale**, więc warto to potwierdzić z konstruktorem.

**Z rzutu „Schemat zbiorczy garaży”:** wszystkie hale mają posadzkę 122,57 (−3,43), lokalnie −3,51 (korytka) i −3,60 (prawdopodobnie studzienki). Rampy mają spadki 15% i 5%, dół rampy ok. 122,60–122,85, góra ok. 125,56–125,83 m. Pole stref pożarowych: hala 2 – 1096,72; 3 – 1392,35; 4 – 1474,97; 5 – 1390,71; 6 – 1390,55; 7 – 1390,55; 8 – 1475,33 m² (hala 1 na rzucie ma wpisane 0,00, prawdopodobnie pomyłka; przyjęto ok. 1390 m²). Razem ok. **11 000 m²**.

Lokalne pogłębienia (podszybia wind, korytka) to tylko kilka–kilkadziesiąt m³ i można je policzyć osobno prostokątami (powierzchnia × głębokość).

**Woda gruntowa:** w 12 z 16 otworów, dla których jest zwierciadło ustabilizowane, leży ono powyżej dna 121,97 (zwykle o 1,0–1,5 m, na rzędnych ok. 123,0–123,5 m). Wykop będzie więc w dużej części **poniżej zwierciadła**: potrzebne będzie odwodnienie, a grunt spod wody będzie mokry (ważne dla kosztu wywozu i utylizacji). Objętość tę policzysz z powierzchnią `ZW` (Krok 7, pozycja 7.6).

---

## Krok 7. Liczenie objętości (Volumes Dashboard)

1. Zakładka **Analyze → Volumes and Materials → Volumes Dashboard** (panel objętości). Otworzy się okno, zwykle na dole.
2. Każdą objętość tworzysz przyciskiem **Create new volume surface** (pierwsza ikona w panelu):
   - **Name**: nazwa z tabeli,
   - **Base Surface** (powierzchnia bazowa, „dolna/wcześniejsza”) i **Comparison Surface** (porównywana, „górna/późniejsza”) wybierz wg tabeli,
   - **OK**.
3. Liczenie tylko w obrysie: w panelu kliknij ikonę **Add bounded volume** (dodaj objętość w granicy), kliknij nazwę volume surface i wskaż polilinię obrysu. Pod spodem pojawi się wiersz z wynikiem dla tego obrysu.
4. Odczytujesz kolumny **Cut** (wykop) i **Fill** (nasyp/przyrost) w m³.

| Nr | Volume surface | Base | Comparison | Obrys | Odczytaj | Co to jest |
|---|---|---|---|---|---|---|
| 7.1 | `VOL_HUMUS` | ZERO | TH_HUMUS | ZAKRES_HUMUS | **Fill** | **V1** – cały humus do zdjęcia |
| 7.2 | `VOL_NASYP` | ZERO | TH_NASYP | ZAKRES_HUMUS | **Fill** | **V2** – cały nasyp |
| 7.3 | `VOL_WYKOP` | EG | WYKOP | DNO_WYKOPU (6A) / cała powierzchnia (6B) | **Cut** | **V3** – wykop liczony od dzisiejszego terenu |
| 7.4 | `VOL_HUMUS` i `VOL_NASYP` (te same) | – | – | GORA_WYKOPU | **Fill** | **V4**, **V5** – humus i nasyp w obrysie wykopu |
| 7.5 | `VOL_PIASEK_xxx` | ZERO | TH_PIASEK_xxx | DNO_WYKOPU | **Fill** | **V7** – piaski i pospółki w wykopie |
| 7.6 (opc.) | `VOL_POD_WODA` | ZW | WYKOP | jak w 7.3 | **Cut** | wykop poniżej zwierciadła wody, czyli grunt mokry |

**Co z tego wynika:**
- **V6 = V3 − V4 − V5**: grunt rodzimy w wykopie (bez humusu i nasypu, które zdejmujesz wcześniej).
- **V8 = V6 − V7**: gliny w wykopie.
- Piaski dla dna pomiędzy rzędnymi plików: policz V7 dla rzędnej niższej i wyższej, potem interpoluj liniowo. Dla dna 121,97 masz gotowy plik `121_97`, więc interpolacja nie jest potrzebna.
- Przy skarpach piaski liczone w obrysie dna są lekko zaniżone, bo piaski pod skarpą nie są doliczone. Dla kontroli policz je też w obrysie GORA_WYKOPU. Prawda leży mniej więcej pośrodku.

---

## Krok 8. Sprawdź, czy wyniki mają sens

| Kontrola | Oczekiwana wartość |
|---|---|
| V1 / pole ZAKRES_HUMUS | **0,55–0,70 m** (średnia z otworów 0,63 m) |
| Szacunek z otworów (wieloboki Thiessena) w obrysie otworów, ok. 15 480 m² | humus ok. **9 600 m³**, nasyp ok. **600 m³** (nasyp raczej zawyżony, bo w rzeczywistości jest punktowy) |
| V4 < V1 i V5 < V2 | zawsze |
| V3 / pole DNO_WYKOPU (przy ścianach pionowych) | ≈ (średnia rzędna terenu − rzędna dna), np. 124,65 − 121,97 ≈ 2,68 m (bez humusu: ok. 2,0 m) |
| V7 / V6 | dla dna 121,97 ok. **20%** (średnia z otworów; piaski są głównie przy otworach 2, 11, 14, 20, 23) |

Jeśli coś wychodzi kilka razy za dużo albo za mało, sprawdź najczęstsze błędy z Kroku 10.

---

## Krok 9. Bilans: odkład czy wywóz, m³ i tony

Otwórz `02_zestawienia_excel/bilans_robot_ziemnych.xlsx` i wpisz w **żółte pola**:
- V1, V2, V3, V4, V5, V7 z Kroku 7,
- pole terenów zielonych i grubość humusowania,
- ile zasypek (np. wokół ścian garażu) chcesz wykonać z gruntu z wykopu,
- jaki procent piasków realnie da się wybrać osobno. Cienkie przewarstwienia 0,2–0,4 m wymieszają się z gliną; grube warstwy (pospółka przy otworze 11, piaski przy 2, 20, 23) da się wybrać.

Arkusz sam policzy:
- **humus na odkład** (ilość potrzebna na zieleń + zapas) i **humus do wywozu** (nadmiar),
- **nasyp do wywozu/utylizacji**,
- **grunt na odkład** (piasek do zasypek) i **grunt do wywozu** (gliny + nadmiar piasku),
- wszystko w **m³ w gruncie rodzimym**, **m³ luzem** (do liczenia kursów samochodów) i **tonach** (do rozliczenia utylizacji).

Współczynniki spulchnienia i gęstości są wpisane jako typowe wartości (gęstości glin i piasków wg zakresów z DGI). Możesz je zmienić w żółtych polach.

---

## Krok 10. Najczęstsze problemy

| Objaw | Przyczyna / rozwiązanie |
|---|---|
| Punkty lądują daleko od mapy | Zamienione X/Y. Format musi być **PNEZD**, nie PENZD. Albo rysunek nie jest w metrach. |
| Objętość humusu ok. 120 razy za duża | W Base/Comparison zamiast `ZERO` jest `EG` albo odwrotnie. Humus = ZERO vs TH_HUMUS. |
| Bounded volume = 0 | Polilinia niezamknięta (Ctrl+1 → Closed = Yes) albo leży poza zasięgiem powierzchni. |
| Powierzchnia EG ma dziwne „szpile” | Do EG trafiły napisy niebędące wysokościami albo punkty z Z=0. Usuń je z definicji (Definition → Drawing Objects → prawy → Remove) albo popraw. |
| Wykop ze skarpami się nie tworzy | Linia dna musi być zamknięta i mieć wysokość, a EG musi sięgać poza górną krawędź skarp. |
| Wyniki zmieniają się po edycji | Powierzchnia jest „Out of date”: kliknij prawym nazwę w Prospectorze → **Rebuild**. |

---

## Krok 11. Bilans wstępny (z rzutu ze ścianką i przekroju 2C)

Arkusz `02_zestawienia_excel/bilans_robot_ziemnych.xlsx`, zakładka **Bilans wstępny**. Wartości wejściowe (pole obrysu, średni teren, humus, nasyp, udział piasków) są pobierane z siatki 10 × 10 m (zakładka **Dane_siatki**). Założenia: dno 121,97, teren projektowany ok. 125,80, pola stref pożarowych hal 11 001 m², wszystkie gliny na wywóz. Teren jest na razie wstępny (z 17 otworów). Po wykonaniu modelu w Civil 3D wpisz jego wyniki do zakładki **Bilans**.

| m³ w gruncie rodzimym | Wariant A: wykop tylko pod halami | Wariant B: cały obszar w ściance |
|---|---|---|
| Wykop brutto (teren → dno) | 34 000 | 53 200 |
| Humus z całego terenu robót | 12 100 | 12 100 |
| Humus na odkład (zieleń 6 000 m² × 0,25 m + 10%) | 1 650 | 1 650 |
| Humus do wywozu | 10 500 | 10 500 |
| Nasyp niekontrolowany (utylizacja) | 780 | 780 |
| Grunt pod humusem w wykopie | 25 800 | 40 300 |
| w tym gliny / piaski | 21 000 / 4 800 | 32 800 / 7 500 |
| w tym poniżej zwierciadła wody (mokry) | 13 700 | 21 400 |
| Zapotrzebowanie na grunt (zasypki + nasyp) | 22 700 | 37 200 |
| Piasek na odkład (zasypki) | 2 400 | 3 700 |
| Grunt do dowiezienia | 20 300 | 33 500 |
| **Razem do wywozu [m³ rodzime]** | **34 600** | **47 800** |
| **Razem do wywozu [m³ luzem]** | 44 100 | 61 000 |
| **Razem do wywozu [tony]** | 65 700 | 93 100 |

Czułość: każde 10 cm głębokości wykopu to 1 260 m³ (wariant A) lub 1 960 m³ (wariant B).

---

## Krok 12. Bez Civil 3D: GstarCAD + siatka 10 × 10 m

Jeśli masz tylko GstarCAD, użyj folderu `04_gstarcad_siatka` i jego instrukcji `INSTRUKCJA_GSTARCAD.md`: rysunek DXF z siatką węzłów i rzędnymi, dwa skrypty LISP do eksportu współrzędnych oraz arkusze Excel liczące objętości metodą siatki. Metoda daje te same kategorie wyników co Civil 3D (wykop, humus, nasyp, piaski), z dokładnością ograniczoną głównie jakością rzędnych terenu.

---

## Uwagi do danych z DGI

- Tekst DGI podaje nasyp w otworach 5, 17 i 23. Karty otworów pokazują nasyp w **5, 17 i 20**, a w 23 jest od góry gleba 0,80 m. Pliki wykonano **wg kart**.
- Otwór 11: warstwa 1,5–2,5 m „piasek gruby z domieszką żwiru” ma w karcie symbol `saclSi` (prawdopodobnie literówka). Przyjęto ją jako **piasek** (IIb).
- Zwierciadło wody w pliku 06 to orientacyjny pierwszy poziom ustabilizowany odczytany z kart (dla otworu 17 brak, więc pominięty). Traktuj je szacunkowo.
- Granica humusu w wierceniu mechanicznym ma dokładność ok. ±10 cm. Ostateczne rozliczenie ilości najlepiej zrobić pomiarem geodezyjnym przed i po zdjęciu humusu oraz po wykonaniu wykopu.
